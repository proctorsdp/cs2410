This program may be run one of two ways from the command line.
    - Passing an argument of "cmd" will run the command line interface.
    - Passing an argument of "gui" will run the GUI interface.

EX:
    java -cp cmd-out cs2410.assn3.Main cmd
    java -cp cmd-out cs2410.assn3.Main gui



If you recompile the files into a new directory, you will need to make a copy of the resource directory.
Save a copy of the resource directory containing the custom.css file in the directory where you saved the compiled files.

EX:
    cmd-out
        cs2410
            assn3*
        resource
            custom.css

