package tests.controllerTest;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MineFinderControllerTest {
    @BeforeEach
    void setUp() {
    }

    @Test
    void update() {
    }

    @Test
    void reset() {
    }

    @Test
    void setDifficulty() {
    }

    @Test
    void setSize() {
    }

    @Test
    void setModeText() {
    }

    @Test
    void flagCell() {
    }

    @Test
    void selectCell() {
    }

}